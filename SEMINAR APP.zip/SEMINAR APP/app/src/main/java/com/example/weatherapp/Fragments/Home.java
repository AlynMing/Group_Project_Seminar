package com.example.weatherapp.Fragments;

import androidx.fragment.app.Fragment;

public class Home extends Fragment {
}
