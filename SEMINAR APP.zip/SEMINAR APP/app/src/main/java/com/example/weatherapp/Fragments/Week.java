package com.example.weatherapp.Fragments;

import androidx.fragment.app.Fragment;

public class Week extends Fragment {
}
